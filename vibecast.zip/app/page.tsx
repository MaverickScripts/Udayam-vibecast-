"use client"

import { useState, useEffect, Suspense } from "react"
import dynamic from "next/dynamic"
import { MoonStar, Sun, Volume2, VolumeX, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import WeatherDetails from "@/components/weather-details"
import WeatherForecast from "@/components/weather-forecast"
import LoadingScreen from "@/components/loading-screen"

// Dynamically import the 3D map component to avoid SSR issues
const IndiaMap3D = dynamic(() => import("@/components/india-map-3d"), {
  ssr: false,
  loading: () => <LoadingScreen />,
})

export default function Home() {
  const [darkMode, setDarkMode] = useState(false)
  const [soundEnabled, setSoundEnabled] = useState(false)
  const [selectedState, setSelectedState] = useState<string | null>(null)
  const [weatherData, setWeatherData] = useState<any>(null)
  const [loading, setLoading] = useState(false)

  // Toggle dark mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [darkMode])

  // Fetch weather data when a state is selected
  useEffect(() => {
    if (selectedState) {
      fetchWeatherData(selectedState)
    }
  }, [selectedState])

  const fetchWeatherData = async (stateName: string) => {
    setLoading(true)
    try {
      // Get coordinates for the state capital
      const stateCoordinates = getStateCoordinates(stateName)

      // Fetch current weather data from OpenWeatherMap API
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=${stateCoordinates.lat}&lon=${stateCoordinates.lon}&units=metric&appid=1635890035cbba097fd5c26c8ea672a1`,
      )

      // Fetch forecast data
      const forecastResponse = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?lat=${stateCoordinates.lat}&lon=${stateCoordinates.lon}&units=metric&appid=1635890035cbba097fd5c26c8ea672a1`,
      )

      if (response.ok && forecastResponse.ok) {
        const data = await response.json()
        const forecastData = await forecastResponse.json()

        setWeatherData({
          current: data,
          forecast: forecastData,
          stateName,
        })
      }
    } catch (error) {
      console.error("Error fetching weather data:", error)
    } finally {
      setLoading(false)
    }
  }

  // Play weather ambient sound
  const playWeatherSound = () => {
    if (!soundEnabled || !weatherData) return

    // In a real app, you would play different sounds based on weather condition
    const weatherCondition = weatherData.current.weather[0].main.toLowerCase()
    console.log(`Playing ${weatherCondition} sound`)

    // Sound implementation would go here
  }

  useEffect(() => {
    playWeatherSound()
  }, [soundEnabled, weatherData])

  // Share weather info
  const shareWeather = () => {
    if (!weatherData) return

    const { current, stateName } = weatherData
    const temp = Math.round(current.main.temp)
    const condition = current.weather[0].main

    // Generate emoji based on weather and temperature
    let emoji = "🌤️"
    if (condition.includes("Rain")) emoji = "🌧️"
    if (condition.includes("Cloud")) emoji = "☁️"
    if (condition.includes("Clear") && temp > 30) emoji = "🔥"
    if (condition.includes("Clear") && temp < 30) emoji = "😎"

    const shareText = `${stateName}: ${emoji} ${temp}°C, ${getWeatherVibe(temp, condition)}`

    if (navigator.share) {
      navigator
        .share({
          title: "VibeCast India Weather Update",
          text: shareText,
        })
        .catch((err) => console.error("Error sharing:", err))
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard
        .writeText(shareText)
        .then(() => alert("Weather info copied to clipboard!"))
        .catch((err) => console.error("Error copying to clipboard:", err))
    }
  }

  return (
    <main
      className={`flex min-h-screen flex-col ${darkMode ? "bg-gray-900" : "bg-gradient-to-br from-blue-50 to-purple-50"}`}
    >
      {/* Header */}
      <header className="p-4 flex justify-between items-center">
        <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-500 text-transparent bg-clip-text">
          VibeCast India
        </h1>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => setSoundEnabled(!soundEnabled)} className="rounded-full">
            {soundEnabled ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
          </Button>
          <div className="flex items-center gap-2">
            <Sun className="h-4 w-4" />
            <Switch checked={darkMode} onCheckedChange={setDarkMode} />
            <MoonStar className="h-4 w-4" />
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex flex-col lg:flex-row flex-1">
        {/* 3D Map Container */}
        <div className="w-full lg:w-2/3 h-[50vh] lg:h-auto relative">
          <Suspense fallback={<LoadingScreen />}>
            <IndiaMap3D onStateSelect={setSelectedState} selectedState={selectedState} darkMode={darkMode} />
          </Suspense>
        </div>

        {/* Weather Info Panel */}
        <div className="w-full lg:w-1/3 p-4">
          {selectedState ? (
            <Card
              className={`w-full h-full overflow-auto ${darkMode ? "bg-gray-800 text-white border-gray-700" : "bg-white/80 backdrop-blur-sm"}`}
            >
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-xl">{selectedState}</CardTitle>
                  {weatherData && (
                    <CardDescription className="text-lg font-medium">
                      {Math.round(weatherData.current.main.temp)}°C, {weatherData.current.weather[0].main}
                    </CardDescription>
                  )}
                </div>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={shareWeather}
                  disabled={!weatherData}
                  className="rounded-full"
                >
                  <Share2 className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-32 w-full" />
                    <Skeleton className="h-32 w-full" />
                  </div>
                ) : weatherData ? (
                  <Tabs defaultValue="current">
                    <TabsList className="w-full">
                      <TabsTrigger value="current" className="flex-1">
                        Current
                      </TabsTrigger>
                      <TabsTrigger value="forecast" className="flex-1">
                        Forecast
                      </TabsTrigger>
                    </TabsList>
                    <TabsContent value="current">
                      <WeatherDetails weatherData={weatherData.current} />
                    </TabsContent>
                    <TabsContent value="forecast">
                      <WeatherForecast forecastData={weatherData.forecast} />
                    </TabsContent>
                  </Tabs>
                ) : (
                  <div className="text-center py-8">
                    <p>Loading weather data...</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card
              className={`w-full h-full flex items-center justify-center ${darkMode ? "bg-gray-800 text-white border-gray-700" : "bg-white/80 backdrop-blur-sm"}`}
            >
              <CardContent className="text-center p-8">
                <h3 className="text-xl font-medium mb-2">Select a state on the map</h3>
                <p className="text-muted-foreground">Click or tap on any state to view detailed weather information</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </main>
  )
}

// Helper function to get coordinates for state capitals
function getStateCoordinates(stateName: string) {
  const stateCoordinates: Record<string, { lat: number; lon: number }> = {
    "Andhra Pradesh": { lat: 16.5062, lon: 80.648 }, // Amaravati
    "Arunachal Pradesh": { lat: 27.0844, lon: 93.6053 }, // Itanagar
    Assam: { lat: 26.1433, lon: 91.7898 }, // Dispur
    Bihar: { lat: 25.5941, lon: 85.1376 }, // Patna
    Chhattisgarh: { lat: 21.2514, lon: 81.6296 }, // Raipur
    Goa: { lat: 15.4909, lon: 73.8278 }, // Panaji
    Gujarat: { lat: 23.2156, lon: 72.6369 }, // Gandhinagar
    Haryana: { lat: 30.7333, lon: 76.7794 }, // Chandigarh
    "Himachal Pradesh": { lat: 31.1048, lon: 77.1734 }, // Shimla
    Jharkhand: { lat: 23.3441, lon: 85.3096 }, // Ranchi
    Karnataka: { lat: 12.9716, lon: 77.5946 }, // Bengaluru
    Kerala: { lat: 8.5241, lon: 76.9366 }, // Thiruvananthapuram
    "Madhya Pradesh": { lat: 23.2599, lon: 77.4126 }, // Bhopal
    Maharashtra: { lat: 19.076, lon: 72.8777 }, // Mumbai
    Manipur: { lat: 24.817, lon: 93.9368 }, // Imphal
    Meghalaya: { lat: 25.5788, lon: 91.8933 }, // Shillong
    Mizoram: { lat: 23.7307, lon: 92.7173 }, // Aizawl
    Nagaland: { lat: 25.6751, lon: 94.1086 }, // Kohima
    Odisha: { lat: 20.2961, lon: 85.8245 }, // Bhubaneswar
    Punjab: { lat: 30.7333, lon: 76.7794 }, // Chandigarh
    Rajasthan: { lat: 26.9124, lon: 75.7873 }, // Jaipur
    Sikkim: { lat: 27.3389, lon: 88.6065 }, // Gangtok
    "Tamil Nadu": { lat: 13.0827, lon: 80.2707 }, // Chennai
    Telangana: { lat: 17.385, lon: 78.4867 }, // Hyderabad
    Tripura: { lat: 23.8315, lon: 91.2868 }, // Agartala
    "Uttar Pradesh": { lat: 26.8467, lon: 80.9462 }, // Lucknow
    Uttarakhand: { lat: 30.3165, lon: 78.0322 }, // Dehradun
    "West Bengal": { lat: 22.5726, lon: 88.3639 }, // Kolkata
    Delhi: { lat: 28.6139, lon: 77.209 }, // New Delhi
    // Union Territories
    "Andaman and Nicobar Islands": { lat: 11.6234, lon: 92.7265 }, // Port Blair
    Chandigarh: { lat: 30.7333, lon: 76.7794 }, // Chandigarh
    "Dadra and Nagar Haveli": { lat: 20.1809, lon: 73.0169 }, // Silvassa
    "Daman and Diu": { lat: 20.4283, lon: 72.8397 }, // Daman
    "Jammu and Kashmir": { lat: 34.0837, lon: 74.7973 }, // Srinagar
    Ladakh: { lat: 34.1526, lon: 77.577 }, // Leh
    Lakshadweep: { lat: 10.5667, lon: 72.6417 }, // Kavaratti
    Puducherry: { lat: 11.9416, lon: 79.8083 }, // Puducherry
  }

  return stateCoordinates[stateName] || { lat: 20.5937, lon: 78.9629 } // Default to center of India
}

// Helper function to generate fun weather vibes
function getWeatherVibe(temp: number, condition: string) {
  if (condition.includes("Rain")) {
    return "bring an umbrella ☔"
  } else if (condition.includes("Clear") && temp > 35) {
    return "bring sunscreen 😎"
  } else if (condition.includes("Clear") && temp > 25) {
    return "perfect day to chill 🍹"
  } else if (condition.includes("Cloud")) {
    return "cozy vibes only ☕"
  } else if (temp < 15) {
    return "grab a jacket 🧥"
  } else {
    return "weather's giving good vibes ✨"
  }
}
