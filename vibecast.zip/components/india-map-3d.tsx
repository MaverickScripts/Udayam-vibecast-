"use client"

import { useRef, useState, useEffect } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { OrbitControls, Text, Environment, ContactShadows } from "@react-three/drei"
import { Color, Vector3, type Group } from "three"
import { useMediaQuery } from "@/hooks/use-media-query"

// Define the props for the component
interface IndiaMap3DProps {
  onStateSelect: (stateName: string) => void
  selectedState: string | null
  darkMode: boolean
}

// Main component that renders the 3D map
export default function IndiaMap3D({ onStateSelect, selectedState, darkMode }: IndiaMap3DProps) {
  const isMobile = useMediaQuery("(max-width: 768px)")

  return (
    <Canvas camera={{ position: [0, 10, 20], fov: 50 }} className="w-full h-full">
      <ambientLight intensity={0.5} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
      <pointLight position={[-10, -10, -10]} intensity={0.5} />

      <Environment preset={darkMode ? "night" : "sunset"} />

      <group position={[0, -2, 0]}>
        <IndiaMapModel
          onStateSelect={onStateSelect}
          selectedState={selectedState}
          darkMode={darkMode}
          scale={isMobile ? 0.8 : 1}
        />
        <ContactShadows position={[0, -1, 0]} opacity={0.4} scale={20} blur={1.5} far={4} />
      </group>

      <OrbitControls
        enablePan={!isMobile}
        enableZoom={true}
        minPolarAngle={Math.PI / 6}
        maxPolarAngle={Math.PI / 2}
        minDistance={10}
        maxDistance={30}
        autoRotate={!selectedState}
        autoRotateSpeed={0.5}
      />
    </Canvas>
  )
}

// This component represents the actual 3D model of India
function IndiaMapModel({ onStateSelect, selectedState, darkMode, scale = 1 }: IndiaMap3DProps & { scale?: number }) {
  const group = useRef<Group>(null)
  const [hoveredState, setHoveredState] = useState<string | null>(null)
  const { camera } = useThree()

  // In a real application, you would use a proper 3D model of India with state boundaries
  // For this example, we'll create a simplified version with basic shapes

  // Define states with their positions (simplified for this example)
  const states = [
    { name: "Maharashtra", position: [2, 0, 0], size: [1.8, 0.5, 1.2] },
    { name: "Gujarat", position: [0, 0, 0], size: [1.5, 0.5, 1.5] },
    { name: "Rajasthan", position: [0, 0, -2], size: [2, 0.5, 1.8] },
    { name: "Madhya Pradesh", position: [2, 0, -2], size: [2, 0.5, 1.5] },
    { name: "Karnataka", position: [2, 0, 2], size: [1.5, 0.5, 1.5] },
    { name: "Tamil Nadu", position: [3, 0, 3.5], size: [1.2, 0.5, 1.2] },
    { name: "Kerala", position: [2, 0, 4], size: [1, 0.5, 1] },
    { name: "Andhra Pradesh", position: [4, 0, 2], size: [1.5, 0.5, 1.5] },
    { name: "Telangana", position: [4, 0, 0.5], size: [1.2, 0.5, 1.2] },
    { name: "Odisha", position: [5, 0, -1], size: [1.5, 0.5, 1.5] },
    { name: "West Bengal", position: [6, 0, -2], size: [1.2, 0.5, 1.8] },
    { name: "Bihar", position: [5, 0, -3.5], size: [1.5, 0.5, 1] },
    { name: "Jharkhand", position: [5, 0, -2.5], size: [1, 0.5, 1] },
    { name: "Chhattisgarh", position: [4, 0, -2], size: [1.2, 0.5, 1.5] },
    { name: "Uttar Pradesh", position: [3, 0, -4], size: [2.5, 0.5, 1.8] },
    { name: "Uttarakhand", position: [3, 0, -5.5], size: [1.2, 0.5, 0.8] },
    { name: "Haryana", position: [1, 0, -4], size: [1, 0.5, 1] },
    { name: "Punjab", position: [0, 0, -4.5], size: [1, 0.5, 1] },
    { name: "Himachal Pradesh", position: [1, 0, -5.5], size: [1, 0.5, 0.8] },
    { name: "Jammu and Kashmir", position: [0, 0, -6.5], size: [1.5, 0.5, 1] },
    { name: "Assam", position: [7, 0, -3], size: [1.8, 0.5, 0.8] },
    { name: "Arunachal Pradesh", position: [8, 0, -4], size: [1.5, 0.5, 0.8] },
    { name: "Manipur", position: [8.5, 0, -2.5], size: [0.8, 0.5, 0.8] },
    { name: "Nagaland", position: [8.5, 0, -3.5], size: [0.8, 0.5, 0.8] },
    { name: "Meghalaya", position: [7, 0, -2], size: [1, 0.5, 0.8] },
    { name: "Tripura", position: [8, 0, -1.5], size: [0.8, 0.5, 0.8] },
    { name: "Mizoram", position: [8.5, 0, -1.5], size: [0.8, 0.5, 0.8] },
    { name: "Sikkim", position: [6.5, 0, -4], size: [0.6, 0.5, 0.6] },
    { name: "Goa", position: [1, 0, 2.5], size: [0.6, 0.5, 0.6] },
    { name: "Delhi", position: [2, 0, -3.5], size: [0.5, 0.5, 0.5] },
  ]

  // Focus camera on selected state
  useEffect(() => {
    if (selectedState && group.current) {
      const selectedStateObj = states.find((state) => state.name === selectedState)
      if (selectedStateObj) {
        const targetPosition = new Vector3(
          selectedStateObj.position[0] * scale,
          selectedStateObj.position[1] * scale,
          selectedStateObj.position[2] * scale,
        )

        // Move camera to focus on the selected state
        const cameraPosition = new Vector3().copy(camera.position)
        const direction = new Vector3().subVectors(targetPosition, cameraPosition).normalize()
        const distance = 15 // Distance from the state

        camera.position.copy(targetPosition).sub(direction.multiplyScalar(distance))
        camera.lookAt(targetPosition)
      }
    }
  }, [selectedState, camera, scale])

  // Animate the map
  useFrame((state, delta) => {
    if (group.current && !selectedState) {
      // Gentle floating animation when no state is selected
      group.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.1
    }
  })

  // Handle pointer events
  const handlePointerOver = (stateName: string) => {
    setHoveredState(stateName)
    document.body.style.cursor = "pointer"
  }

  const handlePointerOut = () => {
    setHoveredState(null)
    document.body.style.cursor = "auto"
  }

  const handleClick = (stateName: string) => {
    onStateSelect(stateName)
  }

  return (
    <group ref={group} scale={[scale, scale, scale]}>
      {states.map((state) => {
        const isSelected = selectedState === state.name
        const isHovered = hoveredState === state.name

        // Calculate color based on state
        const baseColor = darkMode ? new Color(0x2a2a2a) : new Color(0xf0f0f0)
        const hoverColor = new Color(0x9333ea) // Purple
        const selectedColor = new Color(0x6d28d9) // Darker purple

        let stateColor = baseColor
        if (isSelected) stateColor = selectedColor
        else if (isHovered) stateColor = hoverColor

        return (
          <group key={state.name} position={state.position}>
            <mesh
              onPointerOver={() => handlePointerOver(state.name)}
              onPointerOut={handlePointerOut}
              onClick={() => handleClick(state.name)}
              receiveShadow
              castShadow
            >
              <boxGeometry args={state.size} />
              <meshStandardMaterial
                color={stateColor}
                metalness={0.1}
                roughness={0.8}
                emissive={isSelected || isHovered ? stateColor : undefined}
                emissiveIntensity={isSelected ? 0.5 : isHovered ? 0.3 : 0}
              />
            </mesh>

            {/* State name label */}
            <Text
              position={[0, state.size[1] + 0.2, 0]}
              fontSize={0.3}
              color={darkMode ? "white" : "black"}
              anchorX="center"
              anchorY="middle"
              visible={isHovered || isSelected}
            >
              {state.name}
            </Text>

            {/* Weather indicator (would be based on actual weather data) */}
            {isSelected && (
              <mesh position={[0, state.size[1] + 0.8, 0]}>
                <sphereGeometry args={[0.2, 16, 16]} />
                <meshStandardMaterial color="#ffcc00" emissive="#ffcc00" emissiveIntensity={0.5} />
              </mesh>
            )}
          </group>
        )
      })}
    </group>
  )
}
