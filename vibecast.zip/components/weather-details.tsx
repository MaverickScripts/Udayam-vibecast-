import { Card, CardContent } from "@/components/ui/card"
import {
  Thermometer,
  Droplets,
  Wind,
  Gauge,
  Eye,
  Sunrise,
  Sunset,
  CloudRain,
  CloudSun,
  Cloud,
  Sun,
  CloudFog,
  CloudLightning,
  CloudSnow,
} from "lucide-react"

interface WeatherDetailsProps {
  weatherData: any
}

export default function WeatherDetails({ weatherData }: WeatherDetailsProps) {
  if (!weatherData) return null

  const { main, weather, wind, visibility, sys } = weatherData

  // Convert timestamps to readable time
  const formatTime = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // Get weather icon based on condition
  const getWeatherIcon = (condition: string) => {
    const iconMap: Record<string, any> = {
      Clear: <Sun className="h-12 w-12 text-yellow-500" />,
      Clouds: <Cloud className="h-12 w-12 text-gray-400" />,
      Rain: <CloudRain className="h-12 w-12 text-blue-400" />,
      Drizzle: <CloudRain className="h-12 w-12 text-blue-300" />,
      Thunderstorm: <CloudLightning className="h-12 w-12 text-purple-500" />,
      Snow: <CloudSnow className="h-12 w-12 text-blue-200" />,
      Mist: <CloudFog className="h-12 w-12 text-gray-300" />,
      Fog: <CloudFog className="h-12 w-12 text-gray-300" />,
      Haze: <CloudFog className="h-12 w-12 text-gray-300" />,
      Dust: <CloudFog className="h-12 w-12 text-yellow-300" />,
      Smoke: <CloudFog className="h-12 w-12 text-gray-500" />,
      default: <CloudSun className="h-12 w-12 text-gray-400" />,
    }

    return iconMap[condition] || iconMap["default"]
  }

  return (
    <div className="space-y-4 mt-4">
      <div className="flex items-center justify-between">
        <div className="flex flex-col">
          <span className="text-4xl font-bold">{Math.round(main.temp)}°C</span>
          <span className="text-sm text-muted-foreground">Feels like {Math.round(main.feels_like)}°C</span>
        </div>
        <div className="flex flex-col items-center">
          {getWeatherIcon(weather[0].main)}
          <span className="text-sm mt-1">{weather[0].description}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 mt-4">
        <Card>
          <CardContent className="p-3 flex items-center gap-2">
            <Thermometer className="h-4 w-4 text-red-500" />
            <div className="text-sm">
              <div className="font-medium">Temperature</div>
              <div className="text-xs text-muted-foreground">
                Min: {Math.round(main.temp_min)}°C / Max: {Math.round(main.temp_max)}°C
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-3 flex items-center gap-2">
            <Droplets className="h-4 w-4 text-blue-500" />
            <div className="text-sm">
              <div className="font-medium">Humidity</div>
              <div className="text-xs text-muted-foreground">{main.humidity}%</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-3 flex items-center gap-2">
            <Wind className="h-4 w-4 text-blue-300" />
            <div className="text-sm">
              <div className="font-medium">Wind</div>
              <div className="text-xs text-muted-foreground">{Math.round(wind.speed * 3.6)} km/h</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-3 flex items-center gap-2">
            <Gauge className="h-4 w-4 text-orange-500" />
            <div className="text-sm">
              <div className="font-medium">Pressure</div>
              <div className="text-xs text-muted-foreground">{main.pressure} hPa</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-3 flex items-center gap-2">
            <Eye className="h-4 w-4 text-gray-500" />
            <div className="text-sm">
              <div className="font-medium">Visibility</div>
              <div className="text-xs text-muted-foreground">{(visibility / 1000).toFixed(1)} km</div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-3 flex items-center gap-2">
            <div className="flex gap-1">
              <Sunrise className="h-4 w-4 text-yellow-500" />
              <Sunset className="h-4 w-4 text-orange-500" />
            </div>
            <div className="text-sm">
              <div className="font-medium">Sun</div>
              <div className="text-xs text-muted-foreground">
                {formatTime(sys.sunrise)} / {formatTime(sys.sunset)}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
