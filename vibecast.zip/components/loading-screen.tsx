export default function LoadingScreen() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-purple-100 to-blue-100">
      <div className="relative w-24 h-24">
        <div className="absolute top-0 w-full h-full rounded-full border-4 border-t-purple-500 border-r-transparent border-b-blue-500 border-l-transparent animate-spin"></div>
        <div className="absolute top-2 left-2 w-20 h-20 rounded-full border-4 border-t-transparent border-r-pink-500 border-b-transparent border-l-pink-300 animate-spin animation-delay-150"></div>
      </div>
      <h2 className="mt-4 text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-500 text-transparent bg-clip-text">
        VibeCast India
      </h2>
      <p className="text-sm text-gray-500 mt-2">Loading weather data...</p>
    </div>
  )
}
