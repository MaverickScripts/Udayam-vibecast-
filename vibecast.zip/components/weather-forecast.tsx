import { Card, CardContent } from "@/components/ui/card"
import { CloudRain, CloudSun, Cloud, Sun, CloudFog, CloudLightning, CloudSnow } from "lucide-react"

interface WeatherForecastProps {
  forecastData: any
}

export default function WeatherForecast({ forecastData }: WeatherForecastProps) {
  if (!forecastData || !forecastData.list) return null

  // Group forecast data by day
  const groupedForecast = forecastData.list.reduce((acc: any, item: any) => {
    const date = new Date(item.dt * 1000).toLocaleDateString()
    if (!acc[date]) {
      acc[date] = []
    }
    acc[date].push(item)
    return acc
  }, {})

  // Get next 5 days
  const days = Object.keys(groupedForecast).slice(0, 5)

  // Get weather icon based on condition
  const getWeatherIcon = (condition: string, size = 6) => {
    const iconMap: Record<string, any> = {
      Clear: <Sun className={`h-${size} w-${size} text-yellow-500`} />,
      Clouds: <Cloud className={`h-${size} w-${size} text-gray-400`} />,
      Rain: <CloudRain className={`h-${size} w-${size} text-blue-400`} />,
      Drizzle: <CloudRain className={`h-${size} w-${size} text-blue-300`} />,
      Thunderstorm: <CloudLightning className={`h-${size} w-${size} text-purple-500`} />,
      Snow: <CloudSnow className={`h-${size} w-${size} text-blue-200`} />,
      Mist: <CloudFog className={`h-${size} w-${size} text-gray-300`} />,
      Fog: <CloudFog className={`h-${size} w-${size} text-gray-300`} />,
      Haze: <CloudFog className={`h-${size} w-${size} text-gray-300`} />,
      default: <CloudSun className={`h-${size} w-${size} text-gray-400`} />,
    }

    return iconMap[condition] || iconMap["default"]
  }

  // Format date to day name
  const formatDay = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString(undefined, { weekday: "short" })
  }

  // Get min and max temperature for a day
  const getDayMinMaxTemp = (forecasts: any[]) => {
    let min = Number.POSITIVE_INFINITY
    let max = Number.NEGATIVE_INFINITY

    forecasts.forEach((forecast) => {
      if (forecast.main.temp_min < min) min = forecast.main.temp_min
      if (forecast.main.temp_max > max) max = forecast.main.temp_max
    })

    return { min: Math.round(min), max: Math.round(max) }
  }

  // Get most common weather condition for a day
  const getDayWeatherCondition = (forecasts: any[]) => {
    const conditions: Record<string, number> = {}

    forecasts.forEach((forecast) => {
      const condition = forecast.weather[0].main
      conditions[condition] = (conditions[condition] || 0) + 1
    })

    let mostCommonCondition = ""
    let highestCount = 0

    Object.entries(conditions).forEach(([condition, count]) => {
      if (count > highestCount) {
        mostCommonCondition = condition
        highestCount = count as number
      }
    })

    return mostCommonCondition
  }

  return (
    <div className="space-y-4 mt-4">
      <h3 className="text-lg font-medium">5-Day Forecast</h3>

      <div className="space-y-2">
        {days.map((day) => {
          const forecasts = groupedForecast[day]
          const { min, max } = getDayMinMaxTemp(forecasts)
          const condition = getDayWeatherCondition(forecasts)

          return (
            <Card key={day}>
              <CardContent className="p-3 flex items-center justify-between">
                <div className="font-medium">{formatDay(day)}</div>
                <div className="flex items-center gap-2">
                  {getWeatherIcon(condition, 5)}
                  <div className="text-sm">
                    <span className="font-medium">{max}°</span>
                    <span className="text-muted-foreground ml-1">{min}°</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <h3 className="text-lg font-medium mt-6">Hourly Forecast</h3>

      <div className="flex overflow-x-auto pb-2 gap-2">
        {forecastData.list.slice(0, 8).map((forecast: any) => {
          const time = new Date(forecast.dt * 1000).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })

          return (
            <Card key={forecast.dt} className="flex-shrink-0">
              <CardContent className="p-3 flex flex-col items-center gap-1">
                <div className="text-sm font-medium">{time}</div>
                {getWeatherIcon(forecast.weather[0].main, 5)}
                <div className="text-sm font-medium">{Math.round(forecast.main.temp)}°</div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
